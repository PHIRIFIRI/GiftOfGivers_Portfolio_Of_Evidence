﻿namespace GiftOfGivers_WebApp1.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;

    public class IncidentReportsController : Controller
    {
        private static List<IncidentReport> _reports = new List<IncidentReport>();

        // GET: IncidentReports
        public IActionResult Index()
        {
            return View(_reports);
        }

        // GET: IncidentReports/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: IncidentReports/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(IncidentReport report)
        {
            if (ModelState.IsValid)
            {
                _reports.Add(report);
                return RedirectToAction(nameof(Index));
            }
            return View(report);
        }
    }

}
