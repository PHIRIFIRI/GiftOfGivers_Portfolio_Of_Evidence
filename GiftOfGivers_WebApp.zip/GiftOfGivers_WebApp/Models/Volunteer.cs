﻿namespace GiftOfGivers_WebApp1.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Volunteer
    {
        public int Id { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        public string TaskAssigned { get; set; }

        public DateTime TaskDate { get; set; }
    }

}
