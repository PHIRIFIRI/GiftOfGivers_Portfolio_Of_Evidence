﻿namespace GiftOfGivers_WebApp1.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Donation
    {
        public int Id { get; set; }

        [Required]
        public string DonorName { get; set; }

        [Required]
        [Display(Name = "Donation Type")]
        public string DonationType { get; set; }

        [Required]
        [Display(Name = "Donation Amount")]
        public decimal Amount { get; set; }

        public string Description { get; set; }
    }

}
