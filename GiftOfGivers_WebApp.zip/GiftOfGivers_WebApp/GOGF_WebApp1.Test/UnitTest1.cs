using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using GiftOfGivers_WebApp1.Controllers;
using GiftOfGivers_WebApp1.Models;
using GiftOfGivers_WebApp1;

namespace GOGF_WebApp1.Test
{
    [TestClass]
    public class HomeControllerTests
    {
        private HomeController _controller;
        private ILogger<HomeController> _logger;

        [TestInitialize]
        public void Setup()
        {
            _logger = new LoggerFactory().CreateLogger<HomeController>();
            _controller = new HomeController(_logger);
        }

        [TestMethod]
        public void Index_Returns_ViewResult()
        {
            // Act
            var result = _controller.Index();

            // Assert
            Assert.IsInstanceOfType(result, typeof(ViewResult));
        }

        [TestMethod]
        public void Privacy_Returns_ViewResult()
        {
            // Act
            var result = _controller.Privacy();

            // Assert
            Assert.IsInstanceOfType(result, typeof(ViewResult));
        }
    

        [TestMethod]
        public void Error_Returns_ViewResult_With_ErrorViewModel()
        {
            // Act
            var result = _controller.Error() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result.Model, typeof(ErrorViewModel));
            Assert.IsNotNull(((ErrorViewModel)result.Model).RequestId);
        }
    }
    [TestClass]
    public class DonationsControllerTests
    {
        private DonationsController _controller;

        [TestInitialize]
        public void Setup()
        {
            _controller = new DonationsController();
        }

        [TestMethod]
        public void Index_Returns_ViewResult_With_Donations_List()
        {
            // Act
            var result = _controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result.Model, typeof(List<Donation>));
        }

        [TestMethod]
        public void Create_Get_Returns_ViewResult()
        {
            // Act
            var result = _controller.Create() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Create_Post_ValidModel_Returns_RedirectToActionResult()
        {
            // Arrange
            var donation = new Donation { /* set necessary properties */ };
            _controller.ModelState.Clear();

            // Act
            var result = _controller.Create(donation) as RedirectToActionResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Index", result.ActionName);
        }

        [TestMethod]
        public void Create_Post_InvalidModel_Returns_ViewResult_With_Model()
        {
            // Arrange
            var donation = new Donation { /* set necessary properties */ };
            _controller.ModelState.AddModelError("Error", "Model is invalid");

            // Act
            var result = _controller.Create(donation) as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(donation, result.Model);
        }
    }
    [TestClass]
    public class IncidentReportsControllerTests
    {
        private IncidentReportsController _controller;

        [TestInitialize]
        public void Setup()
        {
            _controller = new IncidentReportsController();
        }

        [TestMethod]
        public void Index_Returns_ViewResult_With_IncidentReports_List()
        {
            // Act
            var result = _controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result.Model, typeof(List<IncidentReport>));
        }

        [TestMethod]
        public void Create_Get_Returns_ViewResult()
        {
            // Act
            var result = _controller.Create() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Create_Post_ValidModel_Returns_RedirectToActionResult()
        {
            // Arrange
            var report = new IncidentReport { /* set necessary properties */ };
            _controller.ModelState.Clear();

            // Act
            var result = _controller.Create(report) as RedirectToActionResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Index", result.ActionName);
        }

        [TestMethod]
        public void Create_Post_InvalidModel_Returns_ViewResult_With_Model()
        {
            // Arrange
            var report = new IncidentReport { /* set necessary properties */ };
            _controller.ModelState.AddModelError("Error", "Model is invalid");

            // Act
            var result = _controller.Create(report) as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(report, result.Model);
        }
    }
    [TestClass]
    public class VolunteersControllerTests
    {
        private VolunteersController _controller;

        [TestInitialize]
        public void Setup()
        {
            _controller = new VolunteersController();
        }

        [TestMethod]
        public void Index_Returns_ViewResult_With_Volunteers_List()
        {
            // Act
            var result = _controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result.Model, typeof(List<Volunteer>));
        }

        [TestMethod]
        public void Create_Get_Returns_ViewResult()
        {
            // Act
            var result = _controller.Create() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Create_Post_ValidModel_Returns_RedirectToActionResult()
        {
            // Arrange
            var volunteer = new Volunteer { /* set necessary properties */ };
            _controller.ModelState.Clear();

            // Act
            var result = _controller.Create(volunteer) as RedirectToActionResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Index", result.ActionName);
        }

        [TestMethod]
        public void Create_Post_InvalidModel_Returns_ViewResult_With_Model()
        {
            // Arrange
            var volunteer = new Volunteer { /* set necessary properties */ };
            _controller.ModelState.AddModelError("Error", "Model is invalid");

            // Act
            var result = _controller.Create(volunteer) as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(volunteer, result.Model);
        }
    }

}