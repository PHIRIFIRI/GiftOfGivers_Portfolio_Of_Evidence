using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;

namespace GOGF_UI_Testing
{
    [TestClass]
    public class UnitTest1
    {
        private IWebDriver driver;

        [TestInitialize]
        public void Setup()
        {
            // Set up Chrome WebDriver
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        }

        [TestCleanup]
        public void TearDown()
        {
            // Close the browser after each test
            driver.Quit();
        }

        [TestMethod]
        public void TestVolunteerRegistrationFormSubmission()
        {
            driver.Navigate().GoToUrl("https://localhost:7225/Volunteers/Create");

            // Input fields and submit form
            driver.FindElement(By.Name("FullName")).SendKeys("Test Volunteer");
            driver.FindElement(By.Name("TaskAssigned")).SendKeys("Aid Distribution");
            driver.FindElement(By.Name("TaskDate")).SendKeys("2023-10-30");

            // Submit the form
            driver.FindElement(By.CssSelector("button[type='submit']")).Click();

            // Assert successful navigation to the Index page with the new entry
            Assert.IsTrue(driver.PageSource.Contains("Volunteer Management"));
            Assert.IsTrue(driver.PageSource.Contains("Test Volunteer"));
        }

        [TestMethod]
        public void TestIncidentReportSubmission()
        {
            driver.Navigate().GoToUrl("https://localhost:7225/IncidentReports/Create");

            driver.FindElement(By.Name("Title")).SendKeys("Flood Report");
            driver.FindElement(By.Name("Description")).SendKeys("Heavy flooding in the area.");
            driver.FindElement(By.Name("IncidentDate")).SendKeys("2023-10-29");
            driver.FindElement(By.Name("Location")).SendKeys("Downtown");

            driver.FindElement(By.CssSelector("button[type='submit']")).Click();

            Assert.IsTrue(driver.PageSource.Contains("Disaster Incident Reports"));
            Assert.IsTrue(driver.PageSource.Contains("Flood Report"));
        }

        [TestMethod]
        public void TestDonationFormSubmission()
        {
            driver.Navigate().GoToUrl("https://localhost:7225/Donations/Create");

            driver.FindElement(By.Name("DonorName")).SendKeys("John Doe");
            driver.FindElement(By.Name("DonationType")).SendKeys("Medical Supplies");
            driver.FindElement(By.Name("Amount")).SendKeys("500");
            driver.FindElement(By.Name("Description")).SendKeys("Assorted medical supplies.");

            driver.FindElement(By.CssSelector("button[type='submit']")).Click();

            Assert.IsTrue(driver.PageSource.Contains("Resource Donations"));
            Assert.IsTrue(driver.PageSource.Contains("John Doe"));
        }

        [TestMethod]
        public void TestNavigationToIncidentReports()
        {
            driver.Navigate().GoToUrl("https://localhost:7225/");

            driver.FindElement(By.CssSelector("a[href='/IncidentReports']")).Click();

            Assert.IsTrue(driver.Url.Contains("IncidentReports"));
            Assert.IsTrue(driver.PageSource.Contains("Disaster Incident Reports"));
        }

        [TestMethod]
        public void TestNavigationToDonations()
        {
            driver.Navigate().GoToUrl("https://localhost:7225/");

            driver.FindElement(By.CssSelector("a[href='/Donations']")).Click();

            Assert.IsTrue(driver.Url.Contains("Donations"));
            Assert.IsTrue(driver.PageSource.Contains("Resource Donations"));
        }
    }
}
